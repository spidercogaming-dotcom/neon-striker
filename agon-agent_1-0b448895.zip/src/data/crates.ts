import type { Crate } from '../types/game';

export const crates: Crate[] = [
  {
    id: 'basic',
    name: 'Basic Crate',
    price: 100,
    color: '#60a5fa',
    items: [
      { weaponId: 'pistol', chance: 40 },
      { weaponId: 'smg', chance: 30 },
      { weaponId: 'shotgun', chance: 20 },
      { weaponId: 'rifle', chance: 10 }
    ]
  },
  {
    id: 'rare',
    name: 'Rare Crate',
    price: 300,
    color: '#fbbf24',
    items: [
      { weaponId: 'smg', chance: 25 },
      { weaponId: 'shotgun', chance: 30 },
      { weaponId: 'rifle', chance: 25 },
      { weaponId: 'sniper', chance: 15 },
      { weaponId: 'minigun', chance: 5 }
    ]
  },
  {
    id: 'epic',
    name: 'Epic Crate',
    price: 500,
    color: '#a78bfa',
    items: [
      { weaponId: 'shotgun', chance: 20 },
      { weaponId: 'rifle', chance: 25 },
      { weaponId: 'sniper', chance: 30 },
      { weaponId: 'minigun', chance: 15 },
      { weaponId: 'laser', chance: 10 }
    ]
  },
  {
    id: 'legendary',
    name: 'Legendary Crate',
    price: 1000,
    color: '#fb923c',
    items: [
      { weaponId: 'rifle', chance: 15 },
      { weaponId: 'sniper', chance: 25 },
      { weaponId: 'minigun', chance: 30 },
      { weaponId: 'laser', chance: 30 }
    ]
  }
];
