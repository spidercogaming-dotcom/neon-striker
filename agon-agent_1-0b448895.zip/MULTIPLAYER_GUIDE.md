# 🎮 Neon Strike - Real Online Multiplayer

## ✅ What's Been Built

### Frontend (React + Vite)
- ✅ Practice Mode (solo vs bots)
- ✅ Simulated Online Mode (AI bots with player names)
- ✅ **Real Online Multiplayer** (true player-vs-player via WebSocket)
- ✅ Shop system with weapons and skins
- ✅ Crate opening with random rewards
- ✅ Inventory management
- ✅ Persistent progress (localStorage)
- ✅ Beautiful neon glass UI

### Backend (Node.js + Socket.io)
- ✅ Real-time WebSocket server
- ✅ Player synchronization
- ✅ Projectile collision detection
- ✅ Power-up spawning and pickup
- ✅ Room-based gameplay
- ✅ Auto-reconnection support

---

## 🌐 How to Get Real Online Multiplayer Working

### Quick Start (3 Steps)

#### Step 1: Deploy Server to Render

1. Go to [render.com](https://render.com) and sign up (free)
2. Click **"New +"** → **"Web Service"**
3. Connect your GitHub repository
4. Configure:
   - **Name:** `neon-strike-server`
   - **Root Directory:** `server`
   - **Build Command:** `npm install`
   - **Start Command:** `node server.js`
   - **Environment Variable:** `PORT=10000`
5. Click **Create** and wait 2-3 minutes
6. **Copy your server URL** (e.g., `https://neon-strike-server.onrender.com`)

#### Step 2: Connect Frontend

Create `.env` file in project root:
```env
VITE_SERVER_URL=https://YOUR-SERVER-URL.onrender.com
```

Replace with your actual Render URL.

#### Step 3: Deploy Frontend

```bash
npm run build
npx vercel
```

---

## 🎯 Game Modes Explained

### 1. 🎯 Practice Mode
- **Solo gameplay** vs AI bots
- **Progressive difficulty** - waves get harder
- **Perfect for** testing weapons and learning

### 2. 🤖 Simulated Online  
- **AI bots** with random player names
- **Battle royale style** - bots fight each other
- **Feels like** multiplayer but runs locally
- **No server needed**

### 3. 🌐 Real Online ⭐ NEW!
- **True multiplayer** with real players
- **Real-time sync** via WebSocket
- **Everyone sees** the same game state
- **Requires** deployed server

---

## 📦 File Structure

```
neon-strike/
├── src/
│   ├── components/        # UI components
│   ├── data/            # Weapons, skins, crates data
│   ├── hooks/           # React hooks (game state, socket)
│   ├── pages/           # Game pages (Menu, Shop, Game, OnlineGame)
│   ├── types/           # TypeScript types
│   ├── App.tsx          # Main app
│   └── main.tsx         # Entry point
├── server/              # Backend server
│   ├── server.js        # Socket.io server
│   ├── package.json     # Server dependencies
│   └── render.yaml     # Render config
├── public/              # Static assets
├── .env.example         # Environment variables template
├── DEPLOYMENT_GUIDE.md  # Detailed deployment guide
└── README.md           # General info
```

---

## 🔧 Configuration

### Environment Variables (.env)

```env
# Server URL for real multiplayer
VITE_SERVER_URL=https://your-server.onrender.com
```

### Server Configuration (server/server.js)

- **Port:** Set via `PORT` environment variable (default: 3001)
- **Room:** Currently hardcoded to "main" room
- **Tick rate:** ~60 FPS (16ms updates)
- **Max players:** No hard limit (depends on server resources)

---

## 🎮 Testing Real Multiplayer

### Method 1: Two Browser Tabs
1. Open your game in Chrome
2. Open incognito window
3. Open game again
4. Both should see each other!

### Method 2: Different Devices
1. Deploy both frontend and backend
2. Share frontend URL with a friend
3. Both click "🌐 REAL ONLINE"
4. Play together!

### Method 3: Local Testing
1. Run backend locally: `cd server && npm start`
2. Set `.env`: `VITE_SERVER_URL=http://localhost:3001`
3. Run frontend: `npm run dev`
4. Open in multiple tabs

---

## 🚨 Common Issues & Solutions

### Issue: "Could not connect to game server"

**Solutions:**
1. Check `.env` has correct server URL
2. Verify server is running (check Render dashboard)
3. Look at browser console for WebSocket errors
4. Make sure server isn't spun down (free tier limitation)

### Issue: Players can't see each other

**Solutions:**
1. Both players must be in the same room (currently "main")
2. Check server logs for connection events
3. Verify WebSocket connection is established
4. Refresh both pages

### Issue: High latency/lag

**Solutions:**
1. Choose a Render region close to your players
2. Upgrade to paid tier for better performance
3. Reduce tick rate in server.js (currently 16ms)
4. Optimize game loop

---

## 💰 Costs

### Free Tier (Current Setup)
- **Render:** Free (with spin-down)
- **Vercel:** Free
- **Total:** $0/month

### Limitations:
- Server spins down after 15 min inactivity
- Cold start takes ~30 seconds
- Limited to 512MB RAM
- May not support many concurrent players

### Paid Option (Recommended for Production)
- **Render Starter:** $7/month
- **Vercel Pro:** $20/month (optional)
- **Total:** ~$7-27/month
- **Benefits:** 24/7 uptime, better performance

---

## 🎯 Next Steps

### Immediate
1. ✅ Deploy server to Render
2. ✅ Test with multiple players
3. ✅ Share with friends

### Future Enhancements
- Player authentication (login system)
- Persistent database (PostgreSQL/MongoDB)
- Multiple game rooms/lobbies
- Voice chat integration
- Leaderboards
- Matchmaking system
- Anti-cheat measures
- Mobile support
- More weapons/maps

---

## 📚 Resources

- [Socket.io Documentation](https://socket.io/docs/)
- [Render Documentation](https://render.com/docs)
- [Vercel Documentation](https://vercel.com/docs)
- [React Documentation](https://react.dev)
- [TypeScript Handbook](https://www.typescriptlang.org/docs/)

---

## 🤝 Contributing

Feel free to:
- Report bugs
- Suggest features
- Submit pull requests
- Share your deployments!

---

## 📄 License

MIT License - Free to use and modify!

---

## 🎉 You're Ready!

**To play:**
1. Deploy server to Render (see DEPLOYMENT_GUIDE.md)
2. Update `.env` with server URL
3. Deploy frontend to Vercel
4. Share the URL with friends
5. Click "🌐 REAL ONLINE" and play together!

**Good luck and have fun! 🎮**
