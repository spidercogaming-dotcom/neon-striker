# Neon Strike - Multiplayer Shooter Game

A fun, interactive multiplayer shooter game with shop, crates, coins, and more!

## 🎮 Game Features

- **Three Game Modes:**
  - 🎯 **Practice Mode** - Solo vs bots with progressive waves
  - 🤖 **Simulated Online** - Battle AI bots with player names
  - 🌐 **Real Online** - True multiplayer with real players!

- **Shop System** - Buy weapons and skins
- **Crate System** - Open crates for random rewards
- **Inventory** - Equip your weapons and skins
- **Progression** - Earn coins, track kills/deaths

## 🚀 Quick Start

### Frontend (Vite + React)

```bash
npm install
npm run dev
```

### Backend (Node.js + Socket.io)

```bash
cd server
npm install
npm start
```

## 🌐 Deploying Real Online Multiplayer

### Step 1: Deploy Server to Render

1. **Create a GitHub repository** and push the code
2. **Go to [render.com](https://render.com)** and sign up
3. **Click "New +" → "Web Service"**
4. **Connect your GitHub repository**
5. **Configure the service:**
   - Name: `neon-strike-server`
   - Root Directory: `server`
   - Build Command: `npm install`
   - Start Command: `node server.js`
   - Instance Type: `Free`
6. **Click "Create Web Service"**
7. **Wait for deployment** (takes 2-3 minutes)
8. **Copy your server URL** (e.g., `https://neon-strike-server.onrender.com`)

### Step 2: Connect Frontend to Server

1. **Create `.env` file in project root:**
   ```env
   VITE_SERVER_URL=https://your-server-name.onrender.com
   ```

2. **Replace `your-server-name.onrender.com` with your actual Render URL**

3. **Restart the dev server:**
   ```bash
   npm run dev
   ```

### Step 3: Deploy Frontend to Vercel

```bash
npm run build
npx vercel
```

## 🎯 Game Controls

- **WASD / Arrow Keys** - Move
- **Mouse** - Aim
- **Click** - Shoot
- **R** - Reload
- **ESC** - Pause

## 📦 Server Architecture

The backend uses:
- **Express** - Web server
- **Socket.io** - Real-time WebSocket communication
- **CORS** - Cross-origin requests

### Server Features:
- Real-time player synchronization
- Projectile collision detection
- Power-up spawning
- Player matchmaking
- Room-based gameplay

## 🛠️ Tech Stack

**Frontend:**
- React 19
- TypeScript
- Tailwind CSS v4
- Framer Motion
- Socket.io Client

**Backend:**
- Node.js
- Express
- Socket.io
- CORS

## 💡 Tips

- The server needs to be **always running** for real multiplayer
- Render's free tier spins down after 15 minutes of inactivity
- First request to a sleeping server takes ~30 seconds to wake up
- Consider upgrading to Render's paid tier for 24/7 availability

## 🐛 Troubleshooting

**Connection Issues:**
- Check that the server URL in `.env` is correct
- Ensure the server is deployed and running
- Check browser console for WebSocket errors

**Server Deployment Issues:**
- Verify the build and start commands in Render
- Check Render logs for errors
- Ensure `PORT` environment variable is set

## 📄 License

MIT License - Feel free to use and modify!
