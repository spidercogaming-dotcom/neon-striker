#!/bin/bash

echo "🚀 Neon Strike - Deployment Helper"
echo "=================================="
echo ""

# Check if .env exists
if [ ! -f .env ]; then
    echo "⚠️  .env file not found!"
    echo ""
    echo "Please create .env file with your server URL:"
    echo "VITE_SERVER_URL=https://your-server-name.onrender.com"
    echo ""
    echo "Copy .env.example to .env and edit it:"
    echo "cp .env.example .env"
    exit 1
fi

echo "✅ .env file found"
echo ""

# Check if server folder exists
if [ ! -d "server" ]; then
    echo "❌ Server folder not found!"
    exit 1
fi

echo "✅ Server folder found"
echo ""

# Ask what to deploy
echo "What would you like to deploy?"
echo "1) Frontend only (Vercel)"
echo "2) Backend only (Render - requires manual setup)"
echo "3) Both"
echo ""
read -p "Enter choice (1-3): " choice

case $choice in
    1)
        echo ""
        echo "📦 Deploying frontend to Vercel..."
        npm run build
        npx vercel --prod
        ;;
    2)
        echo ""
        echo "🖥️  To deploy backend to Render:"
        echo ""
        echo "1. Go to https://render.com"
        echo "2. Click 'New +' → 'Web Service'"
        echo "3. Connect your GitHub repository"
        echo "4. Use these settings:"
        echo "   - Name: neon-strike-server"
        echo "   - Root Directory: server"
        echo "   - Build Command: npm install"
        echo "   - Start Command: node server.js"
        echo "   - Environment Variable: PORT=10000"
        echo ""
        echo "5. After deployment, copy your server URL"
        echo "6. Update .env with: VITE_SERVER_URL=https://your-server.onrender.com"
        echo ""
        read -p "Press Enter after you've deployed to Render..."
        ;;
    3)
        echo ""
        echo "📦 Deploying frontend to Vercel..."
        npm run build
        npx vercel --prod
        echo ""
        echo "🖥️  For backend deployment, see DEPLOYMENT_GUIDE.md"
        ;;
    *)
        echo "❌ Invalid choice"
        exit 1
        ;;
esac

echo ""
echo "✅ Deployment complete!"
echo ""
echo "🎮 Game is ready to play!"
